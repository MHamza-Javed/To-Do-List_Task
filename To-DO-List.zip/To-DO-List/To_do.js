const inputBox = document.getElementById("input-box")
const listContainer = document.getElementById("list-container")
function addTask() {
    const newTask = inputBox.value.trim();
    if (newTask === '') {
        alert("Please write something.");
        return;
    }

    if (newTask.length > 50) {
        alert("Task too long! Please limit to 50 characters.");     // limit Sentence to 50 Characters
        return;
    }
  
    const existingTasks = listContainer.getElementsByTagName("li");                 
    for (let i = 0; i < existingTasks.length; i++) {
        if (existingTasks[i].innerText.replace("×", "").trim().toLowerCase() === newTask.toLowerCase()) {      // Check the condition if same thing has enterned twice
            alert("This task already exists!");
            return;
        }
    }

    let li = document.createElement("li");
    li.innerHTML = newTask;
    listContainer.appendChild(li);

    let span = document.createElement("span");
    span.innerHTML = "\u00d7";
    li.appendChild(span);

    inputBox.value = "";
    saveData();
}


inputBox.addEventListener("input", function () {
    const warning = document.getElementById("char-warning");                // check the overlimit character warning
    if (inputBox.value.length > 50) {                      // sentence should be less than 50
        warning.style.display = "block";
    } else {
        warning.style.display = "none";
    }
});
inputBox.addEventListener("keypress", function (e) {            
    if (e.key === "Enter") {                    // Feature of saving data with Pressing Enter
        addTask();
    }
});

listContainer.addEventListener("click",function(e){
    if(e.target.tagName == "LI"){
        e.target.classList.toggle("checked");   //switch between check and uncheck
        saveData();
    }
    else if(e.target.tagName == "SPAN"){
        e.target.parentElement.remove();       // deleting the Task
        saveData();
    }
},false);

function clearAll() {
    if (confirm("Are you sure you want to delete all tasks?")) {
        listContainer.innerHTML = "";
        saveData();
    }
}
function deleteCompleted() {
    const tasks = listContainer.querySelectorAll("li.checked");
    tasks.forEach(task => task.remove());
    saveData();
}

function    filterTasks(filterType) {
    const tasks = listContainer.querySelectorAll("li");
    tasks.forEach(task => {
        switch(filterType) {
            case 'all':
                task.style.display = "block";
                break;
            case 'completed':
                task.style.display = task.classList.contains("checked")? "block" : "none";    // if check is true it will be displayed
                break;
            case 'pending' :
                task.style.display = !task.classList.contains("checked")? "block" : "none";   // if not check is true it will be displayed
                break;
        }
    });
}
 
function saveData(){
    localStorage.setItem("data", listContainer.innerHTML)  // function to save data locally
}

function showData(){
    listContainer.innerHTML = localStorage.getItem("data");
}
showData();